#' Check the Objective Correctness of Submitted Code
#'
#' @param student_dir path to a single directory with submitted solution
#' scripts (R and not Rmd at the moment)
#' @param solution_file path to a solution script (R and not Rmd at the moment)
#' @param timeout timeout threshold.
#' @param ... optional arguments to FUN.
#' @return Dumb pasted info at this point
#' @examples
#' \dontrun{
#'   correctCheck_directory('ClinicSubmissions-1', 'Solutions-1/Solution3.R',
#'                          timeout = 10)
#' }
#' @export
correctCheck_directory <- function(student_dir, solution_file,
                                   timeout = 10, ...) {

  # This design is possibly fine even if student_dir is a vector of paths,
  # but we need to revisit once we think about possible gradebook usage or
  # some database later on that might require a single dir rather than
  # multiple sections with special dirs.

  # Submissions
  files <- dir(student_dir, full.names = TRUE)
  # How many submissions in student_dir
  n <- length(files)
  # Initilize a list
  k <- vector("list", n)
  # Perform correctCheck on all files to the solution file
  for (i in 1:n) {
    k[[i]] <- correctCheck_object(files[i], solution_file, 
                                  timeout = timeout, ...)
  }
  names(k) <- files
  return(k)
}

#' Check the Objective Correctness of An Object
#' @param x the object that is being compared to `solution_file`
#' @param solution_file path to a submitted solution script (R and not Rmd at
#' the moment)
#' @param timeout timeout threshold.
#' @param ... optional arguments to FUN. (test cases)
#' @details The last line of code (non-empty, non-comment line) in the solution
#' file is what is being evaluated. This will be an important RULE to document!
#' @examples
#' \dontrun{
#' correctCheck_object(answer, 'Solution.R', timeout = 10)
#' correctCheck_object(answer, 'Solution.R', timeout = 10, iris)
#' }
#' @export
correctCheck_object <- function(submission_file, solution_file, 
                                timeout = 10, ...){
  # Put test cases into an accessible form
  inputs <- list(...)
  if (length(inputs) > 0){
    # If we have test case inputs, evaluate the submission/solution on each one
    s <- lapply(inputs, 
                function(i) return(eval_file(solution_file, timeout,i )))
    x <- lapply(inputs, 
                function(i) return(eval_file(submission_file, timeout, i)))
    return(correctTests(x,s))
  } else {
    # In the case where instead they just return a variable, just compare 
    # the outputs directly
    s <- eval_file(solution_file, timeout)
    x <- eval_file(submission_file, timeout)
    ae <- my_allEqual(x,s)
    return(list(score = as.numeric(ae == TRUE), comments = ae))
  }
}

#' Eval an R File
#' @param filename path to a R script (R and not Rmd at the moment)
#' @param timeout timeout threshold.
#' @details We will need to deduce the name of the object from the
#' last line of code (non-empty, non-comment line) in the solution file
#' and this will be an important RULE to document/explain...
#' @examples
#' \dontrun{
#' eval_file('Solution.R', timeout = 10)
#' }
eval_file <- function(filename, timeout = 10, ...) {
  # Read in the script
  mytxt <-  readLines(filename, warn = FALSE)
  mytxt <- gsub("set.seed\\(*\\d*\\)", "set.seed\\(1\\)", mytxt)
  # Avoid breaking if student includes "install.packages"
  mytxt <- gsub("install.packages*", "", mytxt)
  if (!is.function(eval(parse(text = mytxt)))){
    mytxt <- c("function() {", "set.seed(1)", mytxt,
             "return(ans) }")}

  # Create a function
  myfunc <- eval(parse(text = mytxt))
  # Returns the results from the script
  inputs <- list(...)
  if (length(inputs) > 0){
    output <- sapply(inputs, 
                     function(i) return(timeoutCatch(myfunc, timeout, i)))
  } else {
    output <- timeoutCatch(myfunc, timeout)
  }
  return(output)
}


#' Try Catch for internal use
#' @param func the function to be evaluated.
#' @param timeout timeout threshold.
#' @param ... optional arguments to FUN.
#' @importFrom R.utils withTimeout
#' @examples
#' \dontrun{
#' timeoutCatch(myfunction, timeout = 10, iris)
#' }
timeoutCatch <- function(func, timeout = 10, ...) {
  val <- tryCatch({
    withTimeout({
      func(...)
    }, timeout = timeout)
  }, TimeoutException = function(ex) {
    # If evaluation of the function reaches threshold, return 'Timeout!'
    return('Timeout!')
  }, error = function(e){
    # If evaluation of the function results in an error, return 'Code Failure!'
    return('Code Failure!')
  })
  # If evaluation of the function has no problems we return the evaluation
  return(val)
}

#' Modified all.equal for internal use
#' @param target the submission result to be checked
#' @param current The solution result
#' @examples
#' \dontrun{
#' my_allEqual(pi, 355/113)
#' }
my_allEqual <- function(target, current) {
  # If we get Code Failure or Timeout, ignore all.equal
  if (identical(target, "Code Failure!")) {
    return("Code failure!")
  }
  else if (identical(target, "Timeout!")) {
    return("Timeout!")
  }
  else return(all.equal(target, current, check.attributes = FALSE))
}

#' Check similarity between submission and solution (for multiple test cases)
#' @param x the submission result to be checked (should be a list)
#' @param s The solution result to be compared against (should be a list)
#' @details In the event the grader wants to evaluate multiple test cases for 
#' the same problem, this will call my_allEqual on each case individually, and
#' return an easy to interpret list of scores and comments 

correctTests <- function(x, s) {
  # Check each
  ae <- sapply(1:length(x) , function(i) return(my_allEqual(x[i], s[i])))
  score <- as.numeric(ae == TRUE)
  return(list(score = score, comments = ae, grade = mean(score) * 100))
}

#' Generates a table that summarizes the amount of correct submissions and
#' the amount of errors by type and per test case. 
#' @param result_list list of lists containing the results for grading each test
#' case.
#' @param res_name name of the output csv file (without .csv extension), keep
#' empty if no csv is wanted (default = "")
#' @param print_it Turn to TRUE if you want to print out resulting dataframe 
#' @details Used to obtain an overview of the different errors made
#' by the students. The rows stand for which error is made (or TRUE if no error
#' has been made). Each column stands for a specific test case. The values in 
#' each cell is the amount of times that specific comment has occurred 
#' for a specific test case. 
#' 
result_table <- function(result_list, res_name = "", print_it = FALSE) {
  # Calculate number of test cases (based on #comments of first entry)
  n_tc <- length(result_list[[1]]$comments)
  # Initialize the dataframe
  df <- as.data.frame(matrix(nrow = 0, ncol = (n_tc + 1)))
  # Loop over number of test cases (n_tc will probably not be too large)
  for (i in 1:n_tc) {
    # Obtain the amount of message for each type in the 'comments' result
    temp <- table(sapply(result_list, function(x) return(x$comments[i])))
    # Create temporary dataframe with these results and add to full dataframe
    df_temp <- as.data.frame(matrix(nrow = length(temp), ncol = (n_tc + 1)))
    df_temp[1] <- names(temp)
    df_temp[i+1] <- as.numeric(temp)
    df <- rbind(df, df_temp)
  }
  # Refine the dataframe by turning NAs to 0s, aggregating rows and 
  # assigning column names
  df[is.na(df)] <- 0
  df <- aggregate( df[ , -1], by = list(df[ , 1]), FUN = sum)
  colnames(df) <- c("Comment", sapply(1:n_tc, 
                                      function(x) paste0("Test_Case_", x)))
  if (print_it) { print(df) }
  if (length(res_name) > 0) { write.csv(df, paste0(res_name, ".csv"), 
                                        row.names = FALSE) }
  return(df)
}


