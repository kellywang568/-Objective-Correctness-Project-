#' 
#' # A basic calculation requiring a specific answer
#' 

NR <- 4
NC <- 100000
x <- matrix(sample(1:10, NR*NC, replace = TRUE), NR, NC)

### Challenge: calculate the column means; save the answer
### in a vector of length 'NC' called 'ans'.  

#'
#' ### Your work below
#' 
#' When this script is run, it should have created a vector of length
#' `NC` called `ans`.  Obviously we expect it to be numeric and have
#' values that are often close to 5.5 plus or minus a little given
#' what we know about probability and sampling.
#' 
ans <- vector(mode = "character", length = NC)
ans <- colMeans(x)
ans
