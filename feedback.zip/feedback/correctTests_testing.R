library(R.utils)
# Get package
source('correctness.R')
#####################################################################
# Example 1: Return a variable ans
t1 <- correctCheck_directory('ExampleSubmissions-1', 
                            'Example1_Solution1.R', timeout = 3)


result_table(t1)

######################################################################
# Example 2: Write a function, use test cases

# Toy dataframe for testing
df <- data.frame(letters = c('A', 'B', NA, 'X', NA),
                 numbers = c(NA, 31, 14, NA, 89))

# Test on two test cases, iris dataframe and `df` as defined above
t2 <- correctCheck_directory('ExampleSubmissions-2', 'Example2_Solution2.R', 
                            timeout = 3, iris, df)
result_table(t2)

