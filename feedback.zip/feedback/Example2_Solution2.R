## Example 2 solution

myfunc <- function(x) {
  ans <- colSums(is.na(x)) 
  return(ans)     
}